self.__precacheManifest = [
  {
    "revision": "8fbea4021d0d33df8af6",
    "url": "/css/app.b8f1a84b.css"
  },
  {
    "revision": "8fbea4021d0d33df8af6",
    "url": "/js/app.6d97426f.js"
  },
  {
    "revision": "1e05a95951f7e7e355a3",
    "url": "/css/chunk-0727.f09ac38f.css"
  },
  {
    "revision": "1e05a95951f7e7e355a3",
    "url": "/js/chunk-0727.8301bb14.js"
  },
  {
    "revision": "7f88eaff3dbc8b0e228e",
    "url": "/css/chunk-0c80.4c825e57.css"
  },
  {
    "revision": "7f88eaff3dbc8b0e228e",
    "url": "/js/chunk-0c80.c97cfa93.js"
  },
  {
    "revision": "7d51e0760263188302eb",
    "url": "/css/chunk-152f.e9a1287b.css"
  },
  {
    "revision": "7d51e0760263188302eb",
    "url": "/js/chunk-152f.75a0f748.js"
  },
  {
    "revision": "403ea7574f88b23a774d",
    "url": "/css/chunk-17e4.be407f0f.css"
  },
  {
    "revision": "403ea7574f88b23a774d",
    "url": "/js/chunk-17e4.9ac23a3c.js"
  },
  {
    "revision": "093810101b85e56b2dc0",
    "url": "/css/chunk-1a6d.d4bb1833.css"
  },
  {
    "revision": "093810101b85e56b2dc0",
    "url": "/js/chunk-1a6d.4b61d18e.js"
  },
  {
    "revision": "54d29f167f2c47ba8985",
    "url": "/css/chunk-25bf.ae3058d6.css"
  },
  {
    "revision": "54d29f167f2c47ba8985",
    "url": "/js/chunk-25bf.7f1e0cc1.js"
  },
  {
    "revision": "3a3234a35a19c95e3453",
    "url": "/css/chunk-4922.88aa1213.css"
  },
  {
    "revision": "3a3234a35a19c95e3453",
    "url": "/js/chunk-4922.aa9e5db7.js"
  },
  {
    "revision": "12b314cb9534c3ddd2a2",
    "url": "/css/chunk-49d0.48ed3259.css"
  },
  {
    "revision": "12b314cb9534c3ddd2a2",
    "url": "/js/chunk-49d0.171c686f.js"
  },
  {
    "revision": "b8ffcdb1c1cd158797ba",
    "url": "/css/chunk-4d9d.cf3db482.css"
  },
  {
    "revision": "b8ffcdb1c1cd158797ba",
    "url": "/js/chunk-4d9d.4f4162ff.js"
  },
  {
    "revision": "471a4ee16d6f98e21978",
    "url": "/css/chunk-52d2.4c7d01bd.css"
  },
  {
    "revision": "471a4ee16d6f98e21978",
    "url": "/js/chunk-52d2.282c7628.js"
  },
  {
    "revision": "e2e04de00f4967d6ed89",
    "url": "/css/chunk-55f0.980040c0.css"
  },
  {
    "revision": "e2e04de00f4967d6ed89",
    "url": "/js/chunk-55f0.9087d689.js"
  },
  {
    "revision": "db79b9a37c0bbac7fd36",
    "url": "/css/chunk-5c59.180998de.css"
  },
  {
    "revision": "db79b9a37c0bbac7fd36",
    "url": "/js/chunk-5c59.5bf15e9b.js"
  },
  {
    "revision": "2f5af1389236a8bd0a3b",
    "url": "/css/chunk-66d7.e0a8f856.css"
  },
  {
    "revision": "2f5af1389236a8bd0a3b",
    "url": "/js/chunk-66d7.17716c54.js"
  },
  {
    "revision": "8e834d33a7ea6c178881",
    "url": "/css/chunk-6c40.f228d8c1.css"
  },
  {
    "revision": "8e834d33a7ea6c178881",
    "url": "/js/chunk-6c40.1b3f477f.js"
  },
  {
    "revision": "ecd4e0acbfd30a309824",
    "url": "/css/chunk-6dee.d917b815.css"
  },
  {
    "revision": "ecd4e0acbfd30a309824",
    "url": "/js/chunk-6dee.a5a18caa.js"
  },
  {
    "revision": "081f224f1a9d28c03cc4",
    "url": "/css/chunk-7945.e68d9714.css"
  },
  {
    "revision": "081f224f1a9d28c03cc4",
    "url": "/js/chunk-7945.cac80891.js"
  },
  {
    "revision": "a8f1736de27ff93bc825",
    "url": "/css/chunk-8cda.8c33711a.css"
  },
  {
    "revision": "a8f1736de27ff93bc825",
    "url": "/js/chunk-8cda.5c14c99e.js"
  },
  {
    "revision": "8b66cd5a71f35872fa58",
    "url": "/css/chunk-9499.5c7b2aee.css"
  },
  {
    "revision": "8b66cd5a71f35872fa58",
    "url": "/js/chunk-9499.d04a18ea.js"
  },
  {
    "revision": "629fbbf64fca2156788c",
    "url": "/css/chunk-9c30.a8a99333.css"
  },
  {
    "revision": "629fbbf64fca2156788c",
    "url": "/js/chunk-9c30.fb4b79a3.js"
  },
  {
    "revision": "d95abeb46437109460b7",
    "url": "/css/chunk-9c34.f7481f5c.css"
  },
  {
    "revision": "d95abeb46437109460b7",
    "url": "/js/chunk-9c34.b0c90a77.js"
  },
  {
    "revision": "0c48b688a60397c77f3f",
    "url": "/css/chunk-aef6.5d2775ba.css"
  },
  {
    "revision": "0c48b688a60397c77f3f",
    "url": "/js/chunk-aef6.843cb9fc.js"
  },
  {
    "revision": "1efad4f1f69e99d614ac",
    "url": "/css/chunk-vendors.dba3ec3b.css"
  },
  {
    "revision": "1efad4f1f69e99d614ac",
    "url": "/js/chunk-vendors.8ef75e00.js"
  },
  {
    "revision": "e73a0647198cfe970de0f003be95cc51",
    "url": "/fonts/fontello.e73a0647.eot"
  },
  {
    "revision": "9354499c2824248511adf85fdf8e4c37",
    "url": "/img/fontello.9354499c.svg"
  },
  {
    "revision": "8d4a4e6f7431d0d7fa92b1df20f38161",
    "url": "/fonts/fontello.8d4a4e6f.woff2"
  },
  {
    "revision": "a782baa8633b1359f9686ffad17e0d76",
    "url": "/fonts/fontello.a782baa8.woff"
  },
  {
    "revision": "068ca2b316db98037bebdd1e4f1b9459",
    "url": "/fonts/fontello.068ca2b3.ttf"
  },
  {
    "revision": "7816cb102c6908b07b363d2d4e43acb6",
    "url": "/img/weixinpay.7816cb10.jpg"
  },
  {
    "revision": "62e92f6edd6712293c5f6a8a056792d4",
    "url": "/img/rustlang-cn-x.62e92f6e.png"
  },
  {
    "revision": "1aadb022d6285c1af5cc5e312ae26ce1",
    "url": "/img/alipay.1aadb022.jpeg"
  },
  {
    "revision": "c797dcac23c073f40beba195861bb10d",
    "url": "/img/rust.c797dcac.png"
  },
  {
    "revision": "f55e6d65dc3f9e06a4be1a8c8a047381",
    "url": "/index.html"
  },
  {
    "revision": "c797dcac23c073f40beba195861bb10d",
    "url": "/img/rust.png"
  }
];